#include <stdio.h>
#include <stdlib.h>


struct node_t
{

double x;
struct node_t *next;

};

struct node_t *add_tail(struct node_t *tail, struct node_t *node);
struct node_t *add_head(struct node_t *head, struct node_t *node);
void add_before(struct node_t *head, struct node_t *node, int destvalue);
void add_after(struct node_t *head, struct node_t *node, int destvalue);
struct node_t *delete_node(struct node_t *head, double delvalue);
void free_node(struct node_t *node);
struct node_t *create_node(double xval);
int count_nodes(struct node_t *head);
void print_list(struct node_t *head);
void print_node(struct node_t *node);
struct node_t *find_node(struct node_t *head, double n);
void delete_list(struct node_t *head);


int main()
{
        struct node_t *head = NULL;
        char buf[32];
        int usrin;
        int usrin1;
        char usrin2;
        int quit = 1;
        double x = 0.0;
        int y = 0;
        double delvalue = 0.0;
        double finder = 0.0;
        int nodechk = 1;

        while(quit)
        {
                printf("1. Enter a number\n");
                printf("2. Delete a number\n");
                printf("3. Print all numbers\n");
                printf("4. Tell how many item in list\n");
                printf("5. Find a number in a list\n");
                printf("6. Quit\n");
                printf("Enter choice :");
                fgets(buf, 32, stdin);
                sscanf(buf, "%d", &usrin);
                switch(usrin){
                case(1) :
                        printf("1. Head of list\n");
                        printf("2. Middle of list\n");
                        printf("3. Tail of list\n");
                        printf("Enter choice :");
                        fgets(buf, 32, stdin);
                        sscanf(buf, "%d", &usrin1);
                        switch(usrin1){
                        case(1) :
                                printf("Enter a value of x :");

                                fgets(buf, 32, stdin);
                                sscanf(buf, "%lf", &x);
                                head = add_head(head, create_node(x));
                                break;
                        case(2) :
                                nodechk = 1;
                                while(nodechk == 1){
                                printf("Enter the node you want to enter before or after\n");
                                fgets(buf, 32, stdin);
                                sscanf(buf, "%d", &y);
                                if(nodechk < 1){
                                        printf("Error no %d node exist in the list.\n",y);
                                }else{
                                        nodechk = 0;
                                }
                                }
                                printf("Enter b# for before and a# for after where # is value for x");

                                while(nodechk == 1){}
                                fgets(buf, 32, stdin);
                                sscanf(buf, "%c%lf", &usrin2, &x);

                                if(usrin2 == 'b'){
                                        add_before(head, create_node(x),y);
                                }else{
                                        add_after(head, create_node(x),y);
                                }

                                break;
                        case(3) :
                                printf("Enter a value of x :");

                                fgets(buf, 32, stdin);
                                sscanf(buf, "%lf", &x);
                                if(head == NULL){
                                head = add_head(head, create_node(x));
                                }else{
                                head = add_tail(head, create_node(x));
                                }
                                break;
                        }
                        break;
                case(2) :
                        printf("Enter a number to delete from the list :");
                        fgets(buf, 32, stdin);
                        sscanf(buf, "%lf", &delvalue);
                        head = delete_node(head, delvalue);
                        break;

                case(3) :
                        print_list(head);
                        break;
                case(4) :
                        printf("There are %d elements in the list\n", count_nodes(head));
                        break;
                case(5) :
                        printf("Enter a number to find in the list  :");
                        fgets(buf, 32, stdin);
                        sscanf(buf, "%lf", &finder);
                        printf("Node with value %lf is at address %p\n", finder, find_node(head, finder));
                        break;
                case(6) :
                        quit = 0;
                        break;
                }
        }




        delete_list(head);
        return 0;
}

/** Adds a node to the tail of a list
 * @param head pointer to head of the list.
 * @param node pointer to the new node to add_tail
*/
struct node_t *add_tail(struct node_t *head, struct node_t *node)
{
        struct node_t *tmp = head;
        while(tmp->next)
        {
                tmp = tmp->next;
        }
        tmp->next = node;
        return head;
}

/** Adds a node to the head of a list
 * @param head pointer to head of the list.
 * @param node pointer to the new node to add to head
 * @return head the new head of the list
*/
struct node_t *add_head(struct node_t *head, struct node_t *node)
{
        node->next = head;
        head = node;
        return head;
}

/** Adds a node before a specific node in the list.
 * @param head pointer to head of the list.
 * @param node pointer to the new node to add before a current node
 * @param destvalue the value of the node that the new node should go before
*/
void add_before(struct node_t *head, struct node_t *node, int destvalue)
{
        struct node_t *tmp = head;
        int count = 1;
        while(count != destvalue && tmp->next)
        {
                tmp = tmp->next;
                count++;
        }
        node->next = tmp->next;
        tmp->next = node;
}

/** Adds a node after a specific node in the list.
 * @param head pointer to head of the list.
 * @param node pointer to the new node to add before a current node
 * @param destvalue the value of the node that the new node should go after
*/
void add_after(struct node_t *head, struct node_t *node, int destvalue)
{
        struct node_t *tmp = head;
        int count = 1;
        while(count != destvalue && tmp->next)
        {
                tmp = tmp->next;
                count++;
        }
        node->next = tmp->next;
        tmp->next = node;

}

/** deletes a node with a specific x value from the list.
 * @param head pointer to the head of the list
 * @param delvalue the x value for the node that is deleted
*/
struct node_t *delete_node(struct node_t *head, double delvalue)
{
        struct node_t *tmp = head;
        struct node_t *tmp2 = NULL;
        if(tmp->x == delvalue){
                tmp = tmp2;
                tmp = tmp->next;
                free_node(tmp2);
                return tmp;
        }
        if(tmp->next == NULL)
        {
                printf("Error Value Not in list cannot delete :\n");
                return head;
        }
        while(tmp->next->x != delvalue)
        {

                tmp = tmp->next;
                if(tmp->next == NULL)
                {
                        printf("Error Value Not in list cannot delete\n");
                        return head;
                }

        }
        tmp2 = tmp->next;
        tmp->next = tmp2->next;
        tmp2->next = NULL;
        free_node(tmp2);
        return head;
}

/** frees a node
 * @param node pointer to the node that is freed
*/
void free_node(struct node_t *node)
{
        free(node);
}

/** creates a node
 * @param xval the x value for the new node
 * @return node the new node
*/
struct node_t *create_node(double xval)
{
        struct node_t *node = malloc(1* sizeof(struct node_t));
        node->x = xval;
        node->next = NULL;
        return node;
}

/** counts the number of nodes that are in the list
 * @param head pointer to the head of the list
 * @return count the number of nodes in the list
*/
int count_nodes(struct node_t *head)
{
        int count = 0;
        while(head)
        {
                head = head->next;
                count++;
        }
        return count;
}

/** Prints out all the nodes including there position, address, x value and next
 * @param head pointer to the head of the list
*/
void print_list(struct node_t *head)
{
        int count = 1;
        while(head)
        {
                printf("Node #%d",count);
                print_node(head);
                head = head->next;
                count++;
        }
}

/** printf out the address, x value, and next of a node
 * @param node pointer to node to be printed
*/
void print_node(struct node_t *node)
{
        printf("  Address :%p", node);
        printf("  x = %lf  Next Address %p\n", node->x, node->next);
}
/** Find the address of a node with a specific x value in the list.
 * @param head pointer to the head of the list
 * @param n the x value of the node that is being found
 * @return the address of the node null if no node with that value is found
*/
struct node_t *find_node(struct node_t *head, double n)
{
        struct node_t *tmp = head;
        int count = 1;
        while(tmp)
        {
                if(tmp->x == n){
                        printf("%lf is in node #%d\n", n, count);
                        return tmp;
                }

                tmp = tmp->next;
                count++;
        }
        printf("Error no node with value cannot find");
        return NULL;
}
/** delete and frees the whole list
 * @param head pointer to the head of the list
*/
void delete_list(struct node_t *head)
{
        struct node_t *tmp;
        while(head->next)
        {
                tmp = head;
                head = head->next;
                free_node(tmp);
        }
}
