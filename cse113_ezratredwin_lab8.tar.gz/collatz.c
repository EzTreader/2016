#include <stdio.h>
#include <stdlib.h>

struct node_t{
        int x;
        struct node_t *next;
};

struct node_t *add_node(struct node_t *tail, int x);
int find_x(int n);
struct node_t *init_list(int x);
void print_list(struct node_t *head);

int main()
{
        struct node_t *head = NULL, *tail = NULL;
        int n;
        char buf[32];
        int count = 1;

        printf("Enter a starting number :");
        fgets(buf, 32, stdin);
        sscanf(buf, "%d", &n);
        printf("n = %d\n", n);
        head = init_list(n);
        tail = head;
        while(n != 1)
        {
                tail = add_node(tail, find_x(n));
                n = find_x(n);
                count++;
        }
        printf("cycle length = %d\n", count++);
        print_list(head);


        return 0;
}

/** creates and adds a node to the tail of a list
 * @param head pointer to head of the list.
 * @param node pointer to the new node to add_tail
*/
struct node_t *add_node(struct node_t *tail, int x)
{
        struct node_t *node = malloc(1 * sizeof(struct node_t));
        node->x = x;
        node->next = NULL;
        tail->next = node;
        tail = node;
        return tail;
}

/** Find the value that should put in the node based on the value of n
 * @param n the value of the last node added
 * @return x the value that should be put in the next node
*/
int find_x(int n)
{
        int x;
        if (n % 2 == 0){
                x = n/2;
        }else{
                x = (3*n)+1;
        }
        return x;
}

/** creates the first node with the value given by the user
 * @param x the value that should go in the first node that was given by the user
 * @return node pointer to the first node of the list
*/
struct node_t *init_list(int x)
{
        struct node_t *node = malloc(1 * sizeof(struct node_t));
        node->x = x;
        node->next = NULL;
        return node;
}

/** Prints out all the nodes including there position, address, x value and next
 * @param head pointer to the head of the list
*/
void print_list(struct node_t *head)
{
        while(head->next)
        {

                printf("%d,",head->x);
                head = head->next;
        }
        printf("%d\n", head->x);
}
