/**
 * @file life.h
 * @brief
 * @author Ezra Tredwin
 * @date 12/5/16
*/
#ifndef LIFE_H_
#define LIFE_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>


#define ERR_MALLOC_FAIL 90


struct matrix_t{
        int y;
        int x;
        int px;
        int py;
        int qx;
        int qy;
        int sprite_rows;
        int sprite_collunms;
        int rows_boundary;
        int collunms_boundary;
};

struct sprite_t{
        int x;
        int y;
        char file;
        struct sprite_t *next;
};

void set_B(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info);
void init_A(unsigned char **A, struct matrix_t *matrix_info, struct sprite_t *head);
struct sprite_t *init_live_list(char *buf, char file, struct sprite_t *head);
void print_matrix(unsigned char **A, int width, int height);
void add_hedge(unsigned char **B, struct matrix_t *matrix_info);
void set_B_torus(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info);
void set_B_klein(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info);
struct sprite_t *init_live_list_105(int x, int y, char file, struct sprite_t *head);
void free_list(struct sprite_t *head);
void free_array(unsigned char **A, struct matrix_t *matrix_info);


#endif
