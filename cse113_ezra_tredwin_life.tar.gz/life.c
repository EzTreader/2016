/**
 * @file life.c
 * @brief Functions for the main in gl.c
 * @details Creates nodes in the list for the starting living values getting the
information from 1.06 or 1.05 files. Initailizes the values of matrix A from the
linked list of starting values. Sets the matrix B based on A with torus, hedge
and klien bottle variations. Frees malloced space.
 * @author Ezra Tredwin
 * @date 12/5/15
 * @todo none
 * @bug none
*/

#include "life.h"

/** Gets the value for a node in a list as a string and adds that node to the
head of the list
 * @param buf string that hold the values to initialize to the node members
 * @param file the file which the information came from
 * @param head head of the list
 * @return head the new head of the list
*/
struct sprite_t *init_live_list(char *buf, char file, struct sprite_t *head)
{
        struct sprite_t *node = NULL;
        node = malloc(sizeof(struct sprite_t));
        if(node == NULL){
                exit(ERR_MALLOC_FAIL);
        }
        node->next = head;
        head = node;
        node->file = file;
        sscanf(buf, "%d %d", &node->x, &node->y);
        return head;
}

/**Adds a node to the head of a linked list
 * @param x the value to assign to the x member of the node
 * @param y the value to assign to the y member of the node
 * @param file the file which the information came from
 * @param head head of the list
 * @return head the new head of the list
*/
struct sprite_t *init_live_list_105(int x, int y, char file, struct sprite_t *head)
{
        struct sprite_t *node = NULL;
        node = malloc(sizeof(struct sprite_t));
        if(node == NULL){
                exit(ERR_MALLOC_FAIL);
        }
        node->next = head;
        head = node;
        node->file = file;
        node->x = x;
        node->y = y;
        return head;
}

/** Initializes the values of a multidimensional array
 * @param A the multidimensional array
 * @param matrix_info structure that holds information about the multidimensional array
 * @param head head of linked list that hold the values to be initialized to 1
*/
void init_A(unsigned char **A, struct matrix_t *matrix_info, struct sprite_t *head)
{
        int i;
        int j;
        struct sprite_t *tmp = head;
        for(i = 0; i < matrix_info->sprite_rows; i++)
        {
                for(j = 0; j < matrix_info->sprite_collunms; j++)
                {
                        A[i][j] = 0;
                }
        }
        while(tmp)
        {
                if(tmp->file == 'f')
                        A[matrix_info->x + tmp->x][matrix_info->y + tmp->y] = 1;
                else if (tmp->file == 'p')
                        A[matrix_info->px + tmp->x][matrix_info->py + tmp->y] = 1;
                else if (tmp->file == 'q')
                        A[matrix_info->qx + tmp->x][matrix_info->qy + tmp->y] = 1;
                tmp = tmp->next;
        }


}

/** Sets the values of matrix B based on the value in matrix A with the border being a hedge
 * @param A matrix A
 * @param B matrix B
 * @param matrix_info structure with information about the matrices
*/
void set_B(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info)
{
        int i;
        int j;
        int count;
        for(i = 1; i < matrix_info->sprite_rows - 1; i++)
        {
                for(j = 1; j < matrix_info->sprite_collunms - 1; j++)
                {
                        B[i][j] = 0;
                        count = 0;
                        if(A[i-1][j-1] == 1){
                                count++;
                        }
                        if(A[i][j-1] == 1){
                                count++;
                        }
                        if(A[i+1][j-1] == 1){
                                count++;
                        }
                        if(A[i-1][j] == 1){
                                count++;
                        }
                        if(A[i+1][j] == 1){
                                count++;
                        }
                        if(A[i - 1][j+1] == 1){
                                count++;
                        }
                        if(A[i][j+1] == 1){
                                count++;
                        }
                        if(A[i + 1][j+1] == 1){
                                count++;
                        }


                        if (count == 2){
                                B[i][j] = A[i][j];
                        }else if(count == 3){
                                B[i][j] = 1;
                        }else{
                                B[i][j] = 0;
                        }
                }
        }
        add_hedge(B,matrix_info);

}

/** Sets the values of matrix B based on the value in matrix A with the border being a torus
 * @param A matrix A
 * @param B matrix B
 * @param matrix_info structure with information about the matrices
*/
void set_B_torus(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info)
{
        int i;
        int iM;
        int iP;
        int j;
        int jM;
        int jP;
        int count;

        for(i = 0; i < matrix_info->sprite_rows; i++)
        {
                for(j = 0; j < matrix_info->sprite_collunms; j++)
                {
                        iM = i - 1;
                        iP = i + 1;
                        jM = j - 1;
                        jP = j + 1;
                        if(i == 0){
                                iM = matrix_info->sprite_rows - 1;
                        }
                        if(j == 0){
                                jM = matrix_info->sprite_collunms - 1;
                        }
                        if(i == matrix_info->sprite_rows - 1){
                                iP = 0;
                        }
                        if(j == matrix_info->sprite_collunms- 1){
                                jP = 0;
                        }
                        B[i][j] = 0;
                        count = 0;
                        if(A[iM][jM] == 1){
                                count++;
                        }
                        if(A[i][jM] == 1){
                                count++;
                        }
                        if(A[iP][jM] == 1){
                                count++;
                        }
                        if(A[iM][j] == 1){
                                count++;
                        }
                        if(A[iP][j] == 1){
                                count++;
                        }
                        if(A[iM][jP] == 1){
                                count++;
                        }
                        if(A[i][jP] == 1){
                                count++;
                        }
                        if(A[iP][jP] == 1){
                                count++;
                        }


                        if (count == 2){
                                B[i][j] = A[i][j];
                        }else if(count == 3){
                                B[i][j] = 1;
                        }else{
                                B[i][j] = 0;
                        }

                }
        }
}

/** Sets the values of matrix B based on the value in matrix A with the border being a klein bottle
 * @param A matrix A
 * @param B matrix B
 * @param matrix_info structure with information about the matrices
*/
void set_B_klein(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info)
{

        {
                int i = 0;
                int iM;
                int iP;
                int j;
                int jM;
                int jP;
                int count;
                int tmpj;
                int tmpjM;
                int tmpjP;

                for( j = 0; j < matrix_info->sprite_collunms; j++)
                {
                        if(j == 0){
                                jM = matrix_info->sprite_collunms - 1;
                        }
                        if(j == matrix_info->sprite_collunms- 1){
                                jP = 0;
                        }
                        tmpj = (2 * matrix_info->collunms_boundary) - (j + 1);
                        tmpjM = tmpj - 1;
                        tmpjP = tmpj + 1;

                        if(tmpj == 0){
                                tmpjM = matrix_info->sprite_collunms - 1;
                        }
                        if(tmpj == matrix_info->sprite_collunms- 1){
                                tmpjP = 0;
                        }
                        iP = i + 1;
                        jM = j - 1;
                        jP = j + 1;

                        iM = matrix_info->sprite_rows - 1;
                        B[i][j] = 0;
                        count = 0;
                        if(A[iM][tmpjM] == 1){
                                count++;
                        }
                        if(A[i][jM] == 1){
                                count++;
                        }
                        if(A[iP][jM] == 1){
                                count++;
                        }
                        if(A[iM][tmpj] == 1){
                                count++;
                        }
                        if(A[iP][j] == 1){
                                count++;
                        }
                        if(A[iM][tmpjP] == 1){
                                count++;
                        }
                        if(A[i][jP] == 1){
                                count++;
                        }
                        if(A[iP][jP] == 1){
                                count++;
                        }


                        if (count == 2){
                                B[i][j] = A[i][j];
                        }else if(count == 3){
                                B[i][j] = 1;
                        }else{
                                B[i][j] = 0;
                        }

                }
                i = matrix_info->sprite_rows - 1;
                for( j = 0; j < matrix_info->sprite_collunms; j++)
                {
                        if(j == 0){
                                jM = matrix_info->sprite_collunms - 1;
                        }
                        if(j == matrix_info->sprite_collunms- 1){
                                jP = 0;
                        }
                        tmpj = (2 * matrix_info->collunms_boundary) - (j + 1);
                        tmpjM = tmpj - 1;
                        tmpjP = tmpj + 1;
                        if(tmpj == 0){
                                tmpjM = matrix_info->sprite_collunms - 1;
                        }
                        if(tmpj == matrix_info->sprite_collunms- 1){
                                tmpjP = 0;
                        }
                        iP = 0;
                        jM = j - 1;
                        jP = j + 1;
                        iM = i - 1;
                        B[i][j] = 0;
                        count = 0;
                        if(A[iM][jM] == 1){
                                count++;
                        }
                        if(A[i][jM] == 1){
                                count++;
                        }
                        if(A[iP][tmpjM] == 1){
                                count++;
                        }
                        if(A[iM][j] == 1){
                                count++;
                        }
                        if(A[iP][tmpj] == 1){
                                count++;
                        }
                        if(A[iM][jP] == 1){
                                count++;
                        }
                        if(A[i][jP] == 1){
                                count++;
                        }
                        if(A[iP][tmpjP] == 1){
                                count++;
                        }


                        if (count == 2){
                                B[i][j] = A[i][j];
                        }else if(count == 3){
                                B[i][j] = 1;
                        }else{
                                B[i][j] = 0;
                        }

                }

                for(i = 1; i < matrix_info->sprite_rows - 1; i++)
                {
                        for(j = 0; j < matrix_info->sprite_collunms; j++)
                        {
                                iM = i - 1;
                                iP = i + 1;
                                jM = j - 1;
                                jP = j + 1;

                                if(j == 0){
                                        jM = matrix_info->sprite_collunms - 1;
                                }
                                if(j == matrix_info->sprite_collunms- 1){
                                        jP = 0;
                                }
                                B[i][j] = 0;
                                count = 0;
                                if(A[iM][jM] == 1){
                                        count++;
                                }
                                if(A[i][jM] == 1){
                                        count++;
                                }
                                if(A[iP][jM] == 1){
                                        count++;
                                }
                                if(A[iM][j] == 1){
                                        count++;
                                }
                                if(A[iP][j] == 1){
                                        count++;
                                }
                                if(A[iM][jP] == 1){
                                        count++;
                                }
                                if(A[i][jP] == 1){
                                        count++;
                                }
                                if(A[iP][jP] == 1){
                                        count++;
                                }


                                if (count == 2){
                                        B[i][j] = A[i][j];
                                }else if(count == 3){
                                        B[i][j] = 1;
                                }else{
                                        B[i][j] = 0;
                                }

                        }
                }
        }

}

/** prints out all the value of a matrix for testing purposes
 * @param A matrix to be printed
 * @param width width of the matrix
 * @param height height of the matrix
*/
void print_matrix(unsigned char **A, int width, int height)
{
        int i;
        int j;
        for(i = 0; i < width; i++)
        {
                printf("r%d[", i);
                for(j = 0; j < height; j++)
                {
                        printf("%c,", A[i][j] + '0');
                }
                printf("\n");
        }
}

/** Add a hedge to a matrix
 * @param B the matrix
 * @param matrix_info structure with infomation on the matrix
*/
void add_hedge(unsigned char **B, struct matrix_t *matrix_info)
{
        int i;
        for(i = 0; i < matrix_info->sprite_rows; i++)
        {
                B[i][0] = 0;
                B[i][matrix_info->sprite_collunms - 1] = 0;
        }
        for(i = 0; i < matrix_info->sprite_collunms; i++)
        {
                B[0][i] = 0;
                B[matrix_info->sprite_rows - 1][i] = 0;
        }
}

/** frees a multidimensional array
 * @param A  matrix the free_array
 * @param matrix_info structure that holds information about the multidimensional array
*/
void free_array(unsigned char **A, struct matrix_t *matrix_info)
{
        int i;
        for(i = 0; i < matrix_info->sprite_rows; i++)
        {
                free(A[i]);
        }
}

/** frees a linked list
 * @param head head of the list
*/
void free_list(struct sprite_t *head)
{
        struct sprite_t *tmp = head;
        while(head)
        {
                tmp = head;
                head = head->next;
                free(tmp);
        }

}
