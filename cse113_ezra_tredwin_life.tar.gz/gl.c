/**
 * @file gl.c
 * @brief Implements conways game of life
 * @details Includes options for torus hedge and klein bottle environments. Also
 includes command line arguments for width, height, color, sprite size, and
 initail coordinate. The program can take input for startng cells from up to
 three files in life 1.06 or life 1.06.
 * @author Ezra Tredwin
 * @date 12/5/15
 * @todo none
 * @bug none
*/
#include <stdlib.h>
#include "SDL2/SDL.h"
#include "sdl.h"
#include "life.h"

int main(int argc, char *argv[])
{
	int c;
	int width = 500;
	int height = 400;
	int sprite_size = 4; /* either 2, 4, 8, or 16 */
	int x = 0;
	int y = 0;
	int px = -1000;
	int py = -1000;
	int qx = -1000;
	int qy = -1000;
	unsigned char red = 140;
	unsigned char green = 145;
	unsigned char blue = 250;
	int border = 0;
	struct sprite_t *head = NULL;
        char buf[1024];
	FILE *in;
	int y105;
	int x105;
	int i;
	int j;

	while((c = getopt(argc, argv, ":w:h:r:g:b:s:f:o:e:P:Q:Hp:q:")) != -1)
	{
	switch(c)
	{

	case 'w' :
		sscanf(optarg, "%d", &width);
		break;
	case 'h' :
		sscanf(optarg, "%d", &height);
		break;
	case 'r' :
		sscanf(optarg, "%hhu", &red);
		break;
	case 'g' :
		sscanf(optarg, "%hhu", &green);
		break;
	case 'b' :
		sscanf(optarg, "%hhu", &blue);
		break;
	case 's' :
		sscanf(optarg, "%d", &sprite_size);
		break;
	case 'f':
		in = fopen(optarg, "r");
		fgets(buf, 1024, in);
		if(buf[9] == '6'){
		while(fgets(buf, 1024, in))
			 head = init_live_list(buf,'f', head);
		}else if (buf[9] == '5'){
			fgets(buf, 1024, in);
			while(buf[1] != 'P')
				fgets(buf, 1024, in);
			sscanf(buf, "#P %d %d", &x105, &y105);
			while(fgets(buf, 1024, in))
			{
				i = 0;
				while(buf[i] != '\0'){
					if(buf[i] == '*'){
						head = init_live_list_105(x105 + i, y105, 'f', head);
					}
					i++;
				}
				y105++;

			}
		}
		fclose(in);
		break;
	case 'e':
		if(tolower(*optarg) == 'h'){
			border = 2;
		}else if(tolower(*optarg) == 'k'){
			border = 1;
		}
		break;
	case 'o':
		sscanf(optarg, "%d,%d", &x, &y);
		break;
	case 'P':
		in = fopen(optarg, "r");
		fgets(buf, 1024, in);
		if(buf[9] == '6'){
		while(fgets(buf, 1024, in))
			 head = init_live_list(buf,'f', head);
		}else if (buf[9] == '5'){
			fgets(buf, 1024, in);
			while(buf[1] != 'P')
				fgets(buf, 1024, in);
			sscanf(buf, "#P %d %d", &x105, &y105);
			while(fgets(buf, 1024, in))
			{
				i = 0;
				while(buf[i] != '\0'){

					if(buf[i] == '*'){
						head = init_live_list_105(x105 + i, y105, 'f', head);
					}
					i++;
				}
				y105++;

			}
		}
		fclose(in);
		break;
	case 'Q':
		in = fopen(optarg, "r");
		fgets(buf, 1024, in);
		if(buf[9] == '6'){
		while(fgets(buf, 1024, in))
			 head = init_live_list(buf,'q', head);
		}else if (buf[9] == '5'){
			fgets(buf, 1024, in);
			while(buf[1] != 'P')
				fgets(buf, 1024, in);
			sscanf(buf, "#P %d %d", &x105, &y105);
			while(fgets(buf, 1024, in))
			{
				i = 0;
				while(buf[i] != '\0'){
					i++;
					if(buf[i] == '*'){
						y105 = i;
						head = init_live_list_105(x105, y105, 'q', head);
					}
				}
				y105++;

			}
		}
		fclose(in);
		break;
	case 'H' :
		printf("Required\n");
		printf("-f filename, a life pattern in file format 1.06 or 1.05.\n Enter #life 1.0# for format at the begginning of the file\n\n");
		printf("Options\n");
		printf("-w width of the screen argument 640, 800, 1024, etc.\n\n");
		printf("-h height of the screen argument 480, 600, 768, etc.\n\n");
		printf("-e type of edge. Values are hedge, torus or klein. Defaults to torus.\n\n");
		printf("-r the red color value, an integer between [0, 255]\n\n");
		printf("-g the green color value, an integer between [0, 255]\n\n");
		printf("-b the blue color value, an integer between [0, 255]\n\n");
		printf("-s size of the sprite. Valid values are 2, 4, 8, or 16 only. An integer.\n\n");
		printf("-o x,y the initial x,y coordinate of the pattern found in the file. No\nspace between the x and y.\n\n");
		printf("-P filename, an addtional life pattern in file format 1.06 or 1.05.\n Enter #life 1.0# for format at the begginning of the file\n\n");
		printf("-Q filename, an additional life pattern in file format 1.06 or 1.05.\n Enter #life 1.0# for format at the begginning of the file\n\n");
		printf("-p x,y the intial coodinate of the patterm found in the second file. No\nspace between the x and y.\n\n");
		printf("-q x,y the intial coodinate of the patterm found in the second file. No\nspace between the x and y.\n");

		return 0;
		break;
	case 'p' :
		sscanf(optarg, "%d,%d", &px, &py);
		break;
	case 'q' :
		sscanf(optarg, "%d,%d", &qx, &qy);
		break;
	}
	}

        /* colors are RGB model valid values [0, 255] */

        struct sdl_info_t sdl_info; /* this is needed to graphically display the game */

        /* set up SDL -- works with SDL2 */
	init_sdl_info(&sdl_info, width, height, sprite_size, red, green, blue);

	/* your life initialization code here */

	struct matrix_t *matrix_info = NULL;
	matrix_info = malloc(sizeof(struct matrix_t));
	if(matrix_info ==  NULL){
		exit(ERR_MALLOC_FAIL);
	}
	matrix_info->sprite_rows = width / sprite_size;
	matrix_info->sprite_collunms = height / sprite_size;
	matrix_info->rows_boundary = matrix_info->sprite_rows / 2;
	matrix_info->collunms_boundary =  matrix_info->sprite_collunms / 2;
	matrix_info->y = matrix_info->collunms_boundary + y;
	matrix_info->x = matrix_info->rows_boundary + x;
	if(px == -1000){
		matrix_info->px = matrix_info->x;
		matrix_info->py = matrix_info->y;
	}else{
		matrix_info->py = matrix_info->collunms_boundary + py;
		matrix_info->px = matrix_info->rows_boundary + px;
	}
	if(qx == -1000){
		matrix_info->qx = matrix_info->x;
		matrix_info->qy = matrix_info->y;
	}else{
		matrix_info->qy = matrix_info->collunms_boundary + qy;
		matrix_info->qx = matrix_info->rows_boundary + qx;
	}
	unsigned char (*A[matrix_info->sprite_rows]);
        unsigned char (*B[matrix_info->sprite_rows]);
        for(i = 0; i < matrix_info->sprite_rows; i++)
        {
                A[i] =  malloc(matrix_info->sprite_collunms * sizeof(unsigned char));
                B[i] =  malloc(matrix_info->sprite_collunms * sizeof(unsigned char));
        }




        init_A(A, matrix_info, head);
	if(border == 2){
		add_hedge(A,matrix_info);
	}
	free_list(head);
	sdl_render_life(&sdl_info, A);
        /* Main loop: loop forever. */
	while (1)
	{
		/* your game of life code goes here  */

		if( border == 2){
			set_B(A,B,matrix_info);
		}else if( border == 1){
			set_B_klein(A,B,matrix_info);
		}else{
		set_B_torus(A,B,matrix_info);
		}

		for(i = 0; i < matrix_info->sprite_rows; i++)
		{
			for(j = 0; j < matrix_info->sprite_collunms; j++)
			{
				A[i][j] = B[i][j];
			}
		}

		if (SDL_GetTicks() % 1 == 0)
			sdl_render_life(&sdl_info, A);

		/* change the  modulus value to slow the rendering */
		//if (SDL_GetTicks() % 1 == 0)
		//	sdl_test(&sdl_info, m, n);

                 /* Poll for events, and handle the ones we care about.
                  * You can click the X button to close the window
                  */
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_KEYDOWN:
				break;
			case SDL_KEYUP:
                        /* If escape is pressed, return (and thus, quit) */
				if (event.key.keysym.sym == SDLK_ESCAPE){
					free_array(A, matrix_info);
					free(matrix_info);
					return 0;
				}
				break;
			case SDL_QUIT:
				free_array(A, matrix_info);
				free(matrix_info);
				return(0);
			}
		}
	}
	free_array(A, matrix_info);
	free(matrix_info);
	return 0;

}
