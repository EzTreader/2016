var searchData=
[
  ['sdl_5finfo_5ft',['sdl_info_t',['../structsdl__info__t.html',1,'']]],
  ['set_5fb',['set_B',['../life_8c.html#ab281f8b2a39be9ccb1db3d30308d16d6',1,'set_B(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info):&#160;life.c'],['../life_8h.html#ab281f8b2a39be9ccb1db3d30308d16d6',1,'set_B(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info):&#160;life.c']]],
  ['set_5fb_5fklein',['set_B_klein',['../life_8c.html#ade06db22d62816df64d55206f0642ecc',1,'set_B_klein(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info):&#160;life.c'],['../life_8h.html#ade06db22d62816df64d55206f0642ecc',1,'set_B_klein(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info):&#160;life.c']]],
  ['set_5fb_5ftorus',['set_B_torus',['../life_8c.html#a1560f402ad67cda0a7b6caf26c603685',1,'set_B_torus(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info):&#160;life.c'],['../life_8h.html#a1560f402ad67cda0a7b6caf26c603685',1,'set_B_torus(unsigned char **A, unsigned char **B, struct matrix_t *matrix_info):&#160;life.c']]],
  ['sprite_5ft',['sprite_t',['../structsprite__t.html',1,'']]]
];
