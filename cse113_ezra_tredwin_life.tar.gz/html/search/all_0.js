var searchData=
[
  ['add_5fhedge',['add_hedge',['../life_8c.html#a9faf41ae63ea7a68aed6e2c838889bf3',1,'add_hedge(unsigned char **B, struct matrix_t *matrix_info):&#160;life.c'],['../life_8h.html#a9faf41ae63ea7a68aed6e2c838889bf3',1,'add_hedge(unsigned char **B, struct matrix_t *matrix_info):&#160;life.c']]]
];
