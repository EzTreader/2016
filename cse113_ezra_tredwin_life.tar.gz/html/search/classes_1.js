var searchData=
[
  ['matrix_5ft',['matrix_t',['../structmatrix__t.html',1,'']]]
];
