var searchData=
[
  ['init_5fa',['init_A',['../life_8c.html#a91b7e6b529f3911a5be9b26bfc470806',1,'init_A(unsigned char **A, struct matrix_t *matrix_info, struct sprite_t *head):&#160;life.c'],['../life_8h.html#a91b7e6b529f3911a5be9b26bfc470806',1,'init_A(unsigned char **A, struct matrix_t *matrix_info, struct sprite_t *head):&#160;life.c']]],
  ['init_5flive_5flist',['init_live_list',['../life_8c.html#adcd304cdacc20c5b301b98d14375b731',1,'init_live_list(char *buf, char file, struct sprite_t *head):&#160;life.c'],['../life_8h.html#adcd304cdacc20c5b301b98d14375b731',1,'init_live_list(char *buf, char file, struct sprite_t *head):&#160;life.c']]],
  ['init_5flive_5flist_5f105',['init_live_list_105',['../life_8c.html#a6511d1e7ca9674f438890fdbfc85e150',1,'init_live_list_105(int x, int y, char file, struct sprite_t *head):&#160;life.c'],['../life_8h.html#a6511d1e7ca9674f438890fdbfc85e150',1,'init_live_list_105(int x, int y, char file, struct sprite_t *head):&#160;life.c']]]
];
