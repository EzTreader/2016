var searchData=
[
  ['free_5farray',['free_array',['../life_8c.html#ace214cabbed0c1fc630486033b1185c2',1,'free_array(unsigned char **A, struct matrix_t *matrix_info):&#160;life.c'],['../life_8h.html#ace214cabbed0c1fc630486033b1185c2',1,'free_array(unsigned char **A, struct matrix_t *matrix_info):&#160;life.c']]],
  ['free_5flist',['free_list',['../life_8c.html#a5dad0621613cbfb2b90800db4acf26dd',1,'free_list(struct sprite_t *head):&#160;life.c'],['../life_8h.html#a5dad0621613cbfb2b90800db4acf26dd',1,'free_list(struct sprite_t *head):&#160;life.c']]]
];
