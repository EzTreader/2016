var searchData=
[
  ['sdl_5finfo_5ft',['sdl_info_t',['../structsdl__info__t.html',1,'']]],
  ['sprite_5ft',['sprite_t',['../structsprite__t.html',1,'']]]
];
