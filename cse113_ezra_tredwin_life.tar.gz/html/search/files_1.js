var searchData=
[
  ['life_2ec',['life.c',['../life_8c.html',1,'']]],
  ['life_2eh',['life.h',['../life_8h.html',1,'']]]
];
