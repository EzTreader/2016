var searchData=
[
  ['print_5fmatrix',['print_matrix',['../life_8c.html#ade841a4bdb7053ba934a940d08e808d7',1,'print_matrix(unsigned char **A, int width, int height):&#160;life.c'],['../life_8h.html#ade841a4bdb7053ba934a940d08e808d7',1,'print_matrix(unsigned char **A, int width, int height):&#160;life.c']]]
];
