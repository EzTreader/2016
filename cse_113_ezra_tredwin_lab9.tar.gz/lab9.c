/**
* @file lab9.c
* @brief Implements a cpu with add subtract and xor or functions.
* @author Ezra Tredwin
* @date 11/21/16
*/


#include <stdio.h>
#include "lab9.h"

int main()
{


        char buf[96];
        //char reset[96];
        char op;
        int error;
        int sign1;
        int sign2;
        struct cpu_t *cpu = malloc(sizeof(struct cpu_t));

        repeat:
        cpu->r1_head = NULL;
        cpu->r2_head = NULL;
        cpu->r3_head = NULL;

        error = 0;
        printf("enter a word_size :");
        fgets(buf, 96, stdin);
        sscanf(buf, "%d", &cpu->word_size);
        error = check_word_size(cpu->word_size);
        if(error){
                goto error;
        }


        printf("unsigned values [y/n]");

        fgets(buf, 96, stdin);
        if(tolower(buf[0]) == 'y'){
                cpu->unsign = 1;
        }else if(tolower(buf[0]) == 'n'){
                cpu->unsign = 0;
        }

        printf("enter a binary expresion :");
        fgets(buf, 96, stdin);

        error  = create_cpu(cpu, buf, &op, &sign1, &sign2);
        if(error){
                goto error;
        }
        struct bit_t *tmp1 = cpu->r1_head;
        while(tmp1)
        {
                printf("%c", tmp1->n);
                tmp1 = tmp1->next;
        }
        printf("\n");
        printf("%c\n", op);
        tmp1 = cpu->r2_head;
        while(tmp1->next->next)
        {
                printf("%c", tmp1->n);
                tmp1 = tmp1->next;
        }
        printf("\n");
        int i;
        for(i = 0; i < cpu->word_size; i++)
        {
                printf("-");
        }
        printf("\n");
        if(op == '+' || op == '-'){
                if(cpu->unsign == 0){
                        if(sign1 == 0){
                                if(sign2 == 0){
                                        if(op == '+'){
                                                addition(cpu);
                                        }else if(op == '-'){
                                                subtraction(cpu);
                                        }
                                }else if(sign2 ==1){
                                        if(op == '+'){
                                                subtraction(cpu);
                                        }else if(op == '-'){
                                                addition(cpu);
                                        }
                                }
                        }else if(sign1 == 1){
                                if(sign2 == 0){
                                        if(op == '+'){
                                                inverse_subtraction(cpu);
                                        }else if(op == '-');
                                                addition(cpu);
                                }else if(sign2 == 1){
                                        if(op == '-'){
                                                subtraction(cpu);
                                        }else if(op == '+'){
                                                addition(cpu);
                                        }
                                }
                        }
                }else{
                        if(op == '+'){
                                addition(cpu);
                        }else if (op == '-'){
                                subtraction(cpu);
                        }
                }
        }else{
                if(op == '|'){
                        or(cpu);
                }else if(op == '&'){
                        and(cpu);
                }else if(op == '^'){
                        xor(cpu);
                }
        }


        print_expression(cpu, op);

        delete_list(cpu->r1_head);
        delete_list(cpu->r2_head);
        delete_list(cpu->r3_head);
        if(repeat() == 1){
                goto repeat;
        }else{
                printf("goodbye");
        }

        error:
        if(error == MALLOC_ERR){
                printf("malloc failed goodbye\n");
                exit(1);
        }
        if(error == WORD_SIZE_ERR){
                printf("error in word size, must be between 1 and 64\n");
                goto repeat;
        }
        if(error == STR_SIZE_ERR1){
                printf("error in input - record 1 - length is greater than wordsize\n");
                goto repeat;
        }
        if(error == STR_ELE_ERR1){
                printf("error in input - record 1 - something other than 1 or 0 entered\n");
                goto repeat;
        }
        if(error == STR_SIZE_ERR2){
                delete_list(cpu->r1_head);
                printf("error in input - record 2 - length is greater than wordsize\n");
                goto repeat;
        }
        if(error == STR_ELE_ERR2){
                delete_list(cpu->r1_head);
                printf("error in input - record 2 - something other than 1 or 0 entered\n");
                goto repeat;
        }
        if(error == OP_ERR){

        }
}
