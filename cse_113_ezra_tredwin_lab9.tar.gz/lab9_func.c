#include <stdio.h>
#include "lab9.h"




/** call the funtion to initialize the record in the cpu
* @param cpu pointer the structure cpu where the record and flags are held
* @param buf string of the user input
* @param op pointer to a variable that will hold the selection value for the
operator
* @param sign1 pointer to a variable that defines whether the first record holds
a negative or positive number
* @param sign32 pointer to a variable that defines whether the second record
hold a negative or positive number
* @return 0 if no error occur an error code otherwise
*/
int create_cpu(struct cpu_t *cpu, char buf[], char *op, int *sign1, int *sign2)
{
        int error = 0;
        size_t buf_size = find_size(buf);
        char *bin_str = malloc(buf_size * sizeof(char));
        strncpy(bin_str, buf, buf_size);
        strtok(bin_str," ");
        error = check_str_ele(bin_str);
        error = check_str_size(bin_str, cpu->word_size);
        if(error){
                free(bin_str);
                return error;
        }
        if(*bin_str == '0'){
                *sign1 = 0;
        }else{
                *sign1 = 1;
        }
        cpu->r1_head = create_cpu_r(cpu->r1_head, bin_str, cpu->word_size);
        free(bin_str);
        char *op_str = malloc(buf_size * sizeof(char));
        strncpy(op_str, buf, buf_size);
        strtok(op_str," ");
        char *tmp = op_str;
        while(*tmp++){
                ;
        }
        sscanf(tmp++, "%c", op);
        free(op_str);
        check_op(op);
        if(error == 1){
                return error;
        }
        char *bin_str2 = malloc(buf_size * sizeof(char));
        strncpy(bin_str2, buf, buf_size);
        char *tmp2 = bin_str2;
        strtok(tmp2," ");
        while(*tmp2++){
                ;
        }
        tmp2++;
        tmp2++;
        error = check_str_ele(tmp2);
        error = check_str_size(tmp2, cpu->word_size);
        if(error == 1){
                free(bin_str2);
                return error;

        }
        if(*bin_str == '0'){
                *sign2 = 0;
        }else{
                *sign2 = 1;
        }
        cpu->r2_head = create_cpu_r(cpu->r2_head, tmp2, cpu->word_size);
        cpu->r2_head = add_record_head(cpu->r2_head, '0');
        cpu->r3_head = init_r(cpu->r3_head, cpu->word_size);
        free(bin_str2);
        set_tail(cpu);

        return error;
}


/** finds the number of elements in a string
* @param buf the string
* @return the number of elements
*/
size_t find_size(char *buf)
{
        size_t count = 0;
        while(*buf++)
        {
                count++;
        }
        return count;
}

/** sets the tail of all the records
* @param cpu pointer to the structure the head of the records are held in
* @return void
*/
void set_tail(struct cpu_t *cpu)
{
        struct bit_t *tmp1 = cpu->r1_head;
        struct bit_t *tmp2 = cpu->r2_head;
        struct bit_t *tmp3 = cpu->r3_head;
        while(tmp1->next){
                tmp1 = tmp1->next;
                tmp2 = tmp2->next;
        }
        while(tmp3->next){
                tmp3 = tmp3->next;
        }

        cpu->r1_tail = tmp1;
        cpu->r2_tail = tmp2;
        cpu->r3_tail = tmp3;

}
/**sets the chars of a string to nodes in a record/linked list
* @param rhead pointer to the head of the linked list;
* @param the word size of the record
* @return the new head of the linked list
*/
struct bit_t *create_cpu_r(struct bit_t *rhead, char buf[], int word_size)
{
        int i;
        char n;
        make_buf_word(buf, word_size);
        rhead = malloc(sizeof(struct bit_t));
        for(i = 1; i <= word_size; i++)
        {
                n = buf[word_size -i];
                rhead = add_record_head(rhead, n);
        }
        return rhead;
}

/** takes a string and adds zeros to the front of it to make it equal to a word
size
* @param buf the string
* @param word_size word size of record
*/
void make_buf_word(char buf[], int word_size)
{
        int count = 0;
        while(buf[count])
        {
                count++;
        }

        char *zero = malloc((count+1) * sizeof(char));
        int i;
        char *tmp;
        tmp = zero;
        *zero = '0';
        zero++;
        *zero = '\0';
        zero = tmp;
        for(i = 0; i < word_size - count; i++)
        {
                tmp = zero;
                *tmp = '0';
                tmp++;
                *tmp = '\0';
                strcat(zero, buf);
                strncpy(buf, zero, word_size);
        }
        free(zero);
}

/** creates a node and adds it the head of the record
* @param head current head of the record
* @param n value for the n value of the new node
* @return the new value for the head or the record
*/
struct bit_t *add_record_head(struct bit_t *head, char n)
{
        struct bit_t *tmp = head;
        struct bit_t *node = malloc(sizeof(struct bit_t));
        if(tmp == NULL){
                tmp = node;
                node->next = NULL;
                return tmp;
        }
        tmp->prev = node;
        node->next = tmp;
        tmp = node;
        node->prev = NULL;
        node->n = n;
        return tmp;
}

/** initializes the result record to 0 equal to the word size_t
* @param head head of the result record
* @param word_size
*/
struct bit_t *init_r(struct bit_t *head, int word_size)
{
        int i;
        char zero = '0';
        head = NULL;
        for(i = 0; i < word_size + 1; i++)
        {
                head = add_record_head(head, zero);
        }
        return head;
}
/** performs addition with the first and secord records and stores the answer
in the third record of a cpu
* @param cpu the cpu that holds the heads of the records
*/
void addition(struct cpu_t *cpu)
{

        unsigned int carry = 0;
        unsigned int x = 0;
        struct bit_t *tmp1 = cpu->r1_tail;
        struct bit_t *tmp2 = cpu->r2_tail;
        struct bit_t *tmp3 = cpu->r3_tail;
        while(tmp1 && tmp2 && tmp3)
        {
                //printf("tmp1\n");
                //printf("%c:%p\n", tmp1->n, tmp1);
                //printf("tmp2\n");
                //printf("%c:%p\n",tmp2->n, tmp2);
                x = ((tmp1->n -'0') + (tmp2->n -'0')) + carry;
                switch(x){
                case 0 :
                        carry = 0;
                        tmp3->n = '0';
                        break;
                case 1 :
                        carry = 0;
                        tmp3->n = '1';
                        break;
                case 2 :
                        carry = 1;
                        tmp3->n = '0';
                        break;
                case 3 :
                        carry = 1;
                        tmp3->n = '1';
                        break;
                }
                tmp1 = tmp1->prev;
                tmp2 = tmp2->prev;
                tmp3 = tmp3->prev;
        }


        if(!carry){
                cpu->carry = 0;
        }else{
                cpu->carry =1;
        }
        cpu->zero = 1;
        struct bit_t *tmp = cpu->r3_head;
        while(tmp)
        {
                if(tmp->n != 0){
                        cpu->zero = 0;
                        break;
                }
                tmp = tmp->next;
        }

}

/** performs subtraction with the first and second record by taking the
complement and then calling addition puts the result in the third record
* @param the cpu in which the head of the records are held in
*/
void subtraction(struct cpu_t *cpu)
{
        struct bit_t *tmp = cpu ->r2_head;
        while(tmp)
        {
                if(tmp->n == '0'){
                        tmp->n = '1';

                }else{
                        tmp->n = '0';
                }
                tmp = tmp->next;
        }
        struct bit_t *tmp2 = cpu->r2_tail;
        tmp = cpu->r1_tail;
        int carry = 1;
        while(tmp)
        {
                if(carry == 0){
                        carry = 0;
                        break;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                        tmp2 = tmp2->prev;
                        tmp = tmp->prev;

                }
        }
        tmp2 = cpu->r2_tail;
        tmp = cpu->r1_tail;
        carry = 1;
        while(tmp)
        {
                if(carry == 0){
                        carry = 0;
                        break;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                        tmp2 = tmp2->prev;
                        tmp = tmp->prev;

                }
        }
        addition(cpu);
}

/** subtract the record 1 from record 2 by taking the complement and then adding
stores the answer in record 3
* @param cpu structurre that holds the head of the records and other information
*/
void inverse_subtraction(struct cpu_t *cpu)
{
        struct bit_t *tmp = cpu->r1_head;
        while(tmp)
        {
                if(tmp->n == '0'){
                        tmp->n = '1';

                }else{
                        tmp->n = '0';
                }
                tmp = tmp->next;
        }
        struct bit_t *tmp2 = cpu->r1_tail;
        int carry = 1;
        while(tmp2)
        {
                if(carry == 0){
                        carry = 0;
                        tmp2 = tmp2->prev;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                tmp2 = tmp2->prev;

                }
        }
        addition(cpu);

}

/**takes the complement of both record 1 and 2 then adds them together stores
the result in record 3
* @param cpu structure that hold the head of the records
*/

void double_subtraction(struct cpu_t *cpu)
{
        struct bit_t *tmp = cpu->r1_head;
        while(tmp)
        {
                if(tmp->n == '0'){
                        tmp->n = '1';

                }else{
                        tmp->n = '0';
                }
                tmp = tmp->next;
        }
        struct bit_t *tmp2 = cpu->r1_tail;
        int carry = 1;
        while(tmp2)
        {
                if(carry == 0){
                        carry = 0;
                        tmp2 = tmp2->prev;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                        tmp2 = tmp2->prev;

                }
        }
        tmp2 = cpu->r1_tail;
        carry = 1;
        while(tmp2)
        {
                if(carry == 0){
                        carry = 0;
                        tmp2 = tmp2->prev;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                        tmp2 = tmp2->prev;

                }
        }



        tmp = cpu->r2_head;
        while(tmp)
        {
                if(tmp->n == '0'){
                        tmp->n = '1';

                }else{
                        tmp->n = '0';
                }
                tmp = tmp->next;
        }
        tmp2 = cpu->r2_head;
        carry = 1;
        while(tmp2)
        {
                if(carry == 0){
                        carry = 0;
                        tmp2 = tmp2->next;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                tmp2 = tmp2->next;

                }
        }
        tmp2 = cpu->r2_head;
        carry = 1;
        while(tmp2)
        {
                if(carry == 0){
                        carry = 0;
                        tmp2 = tmp2->next;
                }else{
                        if(tmp2->n == '1'){
                                tmp2->n = '0';
                        }else{
                                tmp2->n = '1';
                                carry = 0;
                        }
                tmp2 = tmp2->next;

                }
        }

        addition(cpu);
}


/** finds the decimal value of a record
* @param cpu structure that holds the head of the record
* @return the decimal value
*/
long find_decimal(struct cpu_t *cpu)
{
        long decimal = 1;
        int i;
        struct bit_t *tmp = cpu->r3_tail;
        int count = 0;
        for(i = 1; i <= cpu->word_size; i++)
        {
                if(tmp->n == '1'){
                        decimal = decimal + pow(i,2);
                        count++;
                }
                tmp = tmp->prev;
        }
        if(!count){
                return 0;
        }
        return decimal;
}

/** sets the overflow flag in the structure
* @param cpu the structure
*/
void overflow(struct cpu_t *cpu)
{
        if(cpu->r1_head->n == 0 && cpu->r3_head->n == 0 && cpu->r3_head->n == 1){
                cpu->overflow = 1;
        }else{
                cpu->overflow = 0;
        }
}

/** sets the zero flag in the structure
* @param cpu the structure
*/
void zero(struct cpu_t *cpu)
{
        struct bit_t *tmp = cpu->r3_head;
        while(tmp)
        {
                if(tmp->n != 0){
                        cpu->zero = 0;
                        return;
                }
                tmp = tmp->next;
        }
        cpu->zero = 1;
}
/** sets the parity flag in the structure
* @param cpu the structure
*/
void parity(struct cpu_t *cpu)
{
        struct bit_t *tmp = cpu->r3_head;
        int count = 0;
        while(tmp)
        {
                if(tmp->n == 1){
                        count++;
                }
                tmp =tmp->next;
        }
        if(count % 2 == 0){
                cpu->parity = 1;
        }else{
                cpu->parity = 0;
        }
}

/** sets the sign flag in the structure
* @param cpu the structure
*/
void sign(struct cpu_t *cpu)
{
        if(cpu->r3_head->n == 0){
                cpu->sign = 0;
        }else if(cpu->r3_head->n == 1){
                cpu->sign = 1;
        }
}

/** checks if the word_size entered by the user is valid
* @param word_size the word size being checked that the user inputed
* @return 0 if no error else WORD_SIZE_ERR
*/
int check_word_size(int word_size)
{
        if(word_size < 1){
                return WORD_SIZE_ERR;
        }
        if(word_size > 64){
                return WORD_SIZE_ERR;
        }
        return 0;
}

/** checks if the record the user inputed is within the word size
* @param buf pointer to a string of the record
* @param wordsize the wordsize
* @return 0 if no error 1 if error
*/
int check_str_size(char *buf, int wordsize)
{
        int count = 0;
        while(*buf != '\0')
        {
                count++;
                if(count > wordsize){

                        return 1;
                }
                buf++;

        }
        return 0;
}

/** checks if the record the user inputed has only values allowed to be in the
record
* @param buf pointer to a string of the record
* @param wordsize the wordsize
* @return 0 if no error 1 if error
*/
int check_str_ele(char *buf)
{
        while(*buf != '\0')
        {

                if(*buf != '1' && *buf != '0' && *buf != '\n'){
                        return 1;
                }
                buf++;

        }
        return 0;
}

int check_op(char *op)
{
        if(*op != '+' && *op != '-'){
                printf("error in operator\n");
                return 1;
        }
        return 0;
}

void print_expression(struct cpu_t *cpu, char op)
{
        int i = 0;
        struct bit_t *tmp1 = cpu->r1_head;

        tmp1 = cpu->r3_head;
        while(tmp1->next)
        {
                printf("%c", tmp1->n);
                tmp1 = tmp1->next;
        }
        printf("\nflags\n");
        printf("zero: %d\n", cpu->zero);
        printf("carry: %d\n", cpu->carry);
        sign(cpu);
        printf("sign: %d\n", cpu->sign);
        parity(cpu);
        printf("parity: %d\n", cpu->parity);
        zero(cpu);
        if(cpu->unsign == 'y'){
                printf("unsigned decimal: %ld", find_decimal(cpu));
        }else{
                printf("decimal: ");
                if(cpu->sign == 0){
                        ;
                }else{
                        printf("-");
                }
                printf("%ld\n", find_decimal(cpu));
        }


}

void print_list(struct bit_t *head)
{
        while(head)
        {
                printf("%c:%p\n", head->n, head);
                head = head->next;
        }
}

void and(struct cpu_t *cpu)
{
        struct bit_t *tmp1 = cpu->r1_head;
        struct bit_t *tmp2 = cpu->r2_head;
        struct bit_t *tmp3 = cpu->r3_head;

        while(tmp1){
                if(tmp1->n == '0' || tmp2->n == '0'){
                        tmp3->n = '0';
                }else if(tmp1->n == '1' && tmp2->n == '1'){
                        tmp3->n = '1';
                }
        }
        tmp1 = tmp1->next;
        tmp2 = tmp2->next;
        tmp3 = tmp3->next;
        struct bit_t *tmp = cpu->r3_head;
        cpu->zero = 1;
        while(tmp)
        {
                if(tmp->n != '0'){
                        cpu->zero = 0;
                }
        }

}

void xor(struct cpu_t *cpu)
{
        struct bit_t *tmp1 = cpu->r1_head;
        struct bit_t *tmp2 = cpu->r2_head;
        struct bit_t *tmp3 = cpu->r3_head;

        while(tmp1){
                if(tmp1->n == tmp2->n){
                        tmp3->n = '0';
                }else if(tmp1->n != tmp2->n){
                        tmp3->n = '1';
                }
                tmp1 = tmp1->next;
                tmp2 = tmp2->next;
                tmp3 = tmp3->next;
        }
}

void or(struct cpu_t *cpu)
{
        struct bit_t *tmp1 = cpu->r1_head;
        struct bit_t *tmp2 = cpu->r2_head;
        struct bit_t *tmp3 = cpu->r3_head;

        while(tmp1)
        {
                if(tmp1->n == '1' || tmp2->n == '1')
                {
                        tmp3->n = '1';
                }
                tmp1 = tmp1->next;
                tmp2 = tmp2->next;
                tmp3 = tmp3->next;
        }
}

/** delete and frees the whole list
 * @param head pointer to the head of the list
*/
void delete_list(struct bit_t *head)
{
        struct bit_t *tmp;
        while(head)
        {
                tmp = head;
                head = head->next;
                free_node(tmp);
        }
}

/** frees a node
 * @param node pointer to the node that is freed
*/
void free_node(struct bit_t *node)
{
        free(node);
}

/** checks if the user want to do another operation
* return 1 if the user whats to 0 if they dont
*/
int repeat()
{
        char buf[32];
        printf("Do you want to continue [y/n]?: ");
        fgets(buf, 32, stdin);
        if(buf[0] == 'y'){
                return 1;
        }else{
                return 0;
        }
}
