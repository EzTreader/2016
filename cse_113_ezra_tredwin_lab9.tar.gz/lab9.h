#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#define MALLOC_ERR 90
#define WORD_SIZE_ERR 91
#define STR_SIZE_ERR1 92
#define STR_ELE_ERR1 93
#define OP_ERR 94
#define STR_SIZE_ERR2 95
#define STR_ELE_ERR2 96

struct bit_t{
        unsigned char n;

        struct bit_t *prev;
        struct bit_t *next;
};

struct cpu_t {
        int word_size;
        int unsign;
        int overflow;
        int carry;
        int sign;
        int parity;
        int zero;
        struct bit_t *r1_head;
        struct bit_t *r1_tail;
        struct bit_t *r2_head;
        struct bit_t *r2_tail;
        struct bit_t *r3_head;
        struct bit_t *r3_tail;


};
int create_cpu(struct cpu_t *cpu, char buf[], char *op, int *sign1, int *sign2);
struct bit_t *create_cpu_r(struct bit_t *rhead, char buf[], int word_size);
void make_buf_word(char buf[], int word_size);
struct bit_t *add_record_head(struct bit_t *head, char buf);
struct bit_t *init_r(struct bit_t *head, int wordsize);
void addition(struct cpu_t *cpu);
void subtraction(struct cpu_t *cpu);
void inverse_subtraction(struct cpu_t *cpu);
void double_subtraction(struct cpu_t *cpu);
long find_decimal(struct cpu_t *cpu);
void print_expression(struct cpu_t *cpu, char op);
int check_op(char *op);
int check_str_size(char *buf, int wordsize);
int check_str_ele(char *buf);
void overflow(struct cpu_t *cpu);
void zero(struct cpu_t *cpu);
void parity(struct cpu_t *cpu);
void sign(struct cpu_t *cpu);
int check_word_size(int word_size);
size_t find_size(char *buf);
void print_list(struct bit_t *head);
void set_tail(struct cpu_t *cpu);
void xor(struct cpu_t *cpu);
void and(struct cpu_t *cpu);
void or(struct cpu_t *cpu);
int repeat();
void delete_list(struct bit_t *head);
void free_node(struct bit_t *node);
